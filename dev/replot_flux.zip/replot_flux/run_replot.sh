#!/bin/bash
#SBATCH --job-name=replot_flux
#SBATCH --time=04:00:00
#SBATCH --mem=8G
#SBATCH --output=replot_flux_%j.out

# Replot the final difference images of finished runs with the flux
# normalisation (see README.txt). Edit the three paths and the galaxy list.

REPLOT_DIR=/path/to/replot_flux          # this directory (unzipped)
RESULTS_DIR=/path/to/results             # one output directory per galaxy
CONFIG_DIR=/path/to/configs              # <galaxy>_sorted.json

# activate the environment the pipeline runs in (needs spacepylot etc.)
# conda activate muse_astrometric_registration

for g in IC5332 NGC0628 NGC1087 NGC1300 NGC1365 NGC1385 NGC1433 NGC1512 NGC1566 NGC1672 NGC2835 NGC3351 NGC3627 NGC4254 NGC4303 NGC4321 NGC4535 NGC5068; do
    echo "=== $g"
    python "$REPLOT_DIR/replot_final_difference_images.py" \
        "$RESULTS_DIR/$g" "$CONFIG_DIR/${g}_sorted.json" --ref_filter WFI_BB
done
