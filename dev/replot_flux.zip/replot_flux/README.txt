Replotting the final difference images with flux normalisation
==============================================================

You need the same Python environment the pipeline runs in (so spacepylot etc.
are there). Nothing else to install.

One galaxy:

    python replot_final_difference_images.py <galaxy output dir> <galaxy>_sorted.json

That's it - it finds the reference and the input directory in the
run_manifest.json of the run. If the data moved, add:

    --ref_file_path /path/to/reference.fits --input_dir /path/to/MUSE/images

Other options if you need them:

    --ref_filter WFI_BB     filter of the reference (default WFI_BB)
    --table Hybrid          which output table to replot (default Hybrid)
    --images_dir <dir>      where to write (default <galaxy output dir>/final_difference_images_flux)

All galaxies on the cluster: edit the paths at the top of run_replot.sh
(and the conda line), then

    sbatch run_replot.sh

The plots, a copy of the table with FLUX_SCALE and BACKGROUND, and a log end up
in <galaxy output dir>/final_difference_images_flux/. The run itself is not
touched.
